import { ReactElement, createElement } from "react";

export interface HelloWorldSampleProps {
    sampleText?: string;
}

export function HelloWorldSample({ sampleText }: HelloWorldSampleProps): ReactElement {
    return <div className="widget-hello-world">Hello {sampleText}</div>;
}
