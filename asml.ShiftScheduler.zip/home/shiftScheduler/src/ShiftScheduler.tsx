import { ReactElement, createElement } from "react";
import ShiftScheduler from './components/ShiftSchedulerComponent';
import { ShiftSchedulerContainerProps } from "../typings/ShiftSchedulerProps";
import "./ui/ShiftScheduler.css";

export function ShiftSchedulerWidget({ engineers, onEdit }: ShiftSchedulerContainerProps): ReactElement {
    return <ShiftScheduler engineers={engineers} onEdit={onEdit} />;
}
