import { ReactElement, createElement } from "react";
import { HelloWorldSample } from "./components/HelloWorldSample";
import { ShiftSchedulerPreviewProps } from "../typings/ShiftSchedulerProps";

export function preview({ sampleText }: ShiftSchedulerPreviewProps): ReactElement {
    return <HelloWorldSample sampleText={sampleText} />;
}

export function getPreviewCss(): string {
    return require("./ui/ShiftScheduler.css");
}
