import { ReactElement, createElement } from "react";
import { HelloWorldSample } from "./components/HelloWorldSample";
import ShiftScheduler from './components/ShiftScheduler';

import { ShiftSchedulerContainerProps } from "../typings/ShiftSchedulerProps";

import "./ui/ShiftScheduler.css";

export function ShiftScheduler({ sampleText }: ShiftSchedulerContainerProps): ReactElement {
    return <HelloWorldSample sampleText={sampleText ? sampleText : "World"} />;
}
