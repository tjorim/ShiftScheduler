import React from 'react';
import EngineerRow from './EngineerRow';

interface Props {
    teamName: string;
    engineers: shiftScheduler.Engineer[];
    startDate: Date;
    daysCount: number;
    shifts: shiftScheduler.ShiftAssignment[];
    onEdit: mendix.lib.MxObject => void;
}

const TeamSection: React.FC = ({ teamName, engineers, ...rest }) => (

export default TeamSection;
