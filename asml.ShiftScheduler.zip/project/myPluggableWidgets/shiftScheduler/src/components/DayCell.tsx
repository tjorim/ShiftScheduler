import React, { MouseEvent } from 'react';

interface Props {
    date: Date;
    shift?: shiftScheduler.ShiftAssignment;
    onEdit: () => void;
}

const DayCell: React.FC = ({ date, shift, onEdit }) => {
    const handleContext = (e: MouseEvent) => {
        e.preventDefault();
        // TODO: show context menu
    };
    return (
        <div className="day-cell" onDoubleClick={onEdit} onContextMenu={handleContext} title={shift?.Status ?? ''}>
            {shift && (
                <div className={shift - block shift-${shift.Type.toLowerCase()} role-${shift.Role}}>
            {shift.Type}

)}

            );
};

            export default DayCell;
