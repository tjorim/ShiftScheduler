import React from 'react';
import DayCell from './DayCell';
import { addDays } from 'date-fns';

interface Props {
    engineer: shiftScheduler.Engineer;
    startDate: Date;
    daysCount: number;
    shifts: shiftScheduler.ShiftAssignment[];
    onEdit: mendix.lib.MxObject => void;
}

const EngineerRow: React.FC = ({ engineer, startDate, daysCount, shifts, onEdit }) => (

export default EngineerRow;
